# P108 Personal BMD Website Repository
Department of Business Management, Tzu Chi University | P108 GEO Project

This repository contains the complete production-ready source code for Chloe Huang's Personal BMD Website (`index.html`), fulfilling the October 20 homepage draft milestone and ready for GitHub Pages publication.
